public class CartButton extends Button {

    public CartButton(int x, int y, int w, int h){
        super(x, y, w, h);
    }
}
