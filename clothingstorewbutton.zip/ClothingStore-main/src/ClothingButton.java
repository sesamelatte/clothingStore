import processing.core.PApplet;

public class ClothingButton extends Button {
    int x, y, w, h, i;
    public ClothingButton(int x, int y, int w, int h, int i){
        super(x, y, w, h);
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this. i = i;
    }

    public void draw(PApplet p, Clothing c){
        c.draw(p, 200, x, y);
    }
}
