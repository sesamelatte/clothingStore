import processing.core.PApplet;

public abstract class Button {
    int x, y, w, h;
    int buttonColor = 0;
    int textColor = 255;

    public Button(int x, int y, int w, int h){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
    public void draw(PApplet p, String s){
        p.fill(buttonColor);
        p.rect(x, y, w, h);
        float tw = p.textWidth(s);
        float th = p.textAscent() + p.textDescent();
        float tx = x + (w - tw)/2;
        float ty = y + (h + th)/2;
        p.fill(textColor);
        p.text(s, tx, ty);
    }

    public boolean mouseInside(PApplet p){
        if (p.mouseX > this.x && p.mouseX < this.x + this.w && p.mouseY > this.y && p.mouseY < this.y + this.h) {
            return true;
        }
        return false;
    }

    public void invertColor() {
        System.out.println("ran");
        int temp = buttonColor;
        buttonColor = textColor;
        textColor = temp;
    }

    //public abstract void action();
}
