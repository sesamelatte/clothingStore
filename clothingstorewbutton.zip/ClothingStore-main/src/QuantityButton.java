public class QuantityButton extends Button {
    int x, y, w, h, i;

    public QuantityButton(int x, int y, int w, int h, int i){
        super(x, y, w, h);
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.i = i;
    }


}
