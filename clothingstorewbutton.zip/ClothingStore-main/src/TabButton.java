import java.util.ArrayList;

public class TabButton extends Button {
    int x, y, w, h, i;

    public TabButton(int x, int y, int w, int h, int i){
        super(x, y, w, h);
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.i = i;
    }
}
