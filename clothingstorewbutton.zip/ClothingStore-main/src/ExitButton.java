public class ExitButton extends Button {
    int x, y, w, h;
    public ExitButton(int x, int y, int w, int h){
        super(x, y, w, h);
        this.x = x;
        this. y = y;
        this.w = w;
        this.h = h;
    }
}
