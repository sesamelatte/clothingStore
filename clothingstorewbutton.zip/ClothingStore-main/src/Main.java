
import processing.core.PApplet;
import processing.core.PImage;

import java.util.ArrayList;

public class Main extends PApplet {
    int tabIndex, clothingIndex, i;
     Clothing currClothing;
    ArrayList<String> tabs = new ArrayList<>();
    ArrayList<Button> buttons = new ArrayList<>();
    ArrayList<Clothing> ClothesToDisplay = new ArrayList<>();
    ArrayList<Clothing> ClothesInCart = new ArrayList<>();
    ArrayList<Clothing> Pants = new ArrayList<>();
    ArrayList<Clothing> Tops = new ArrayList<>();
    ArrayList<Clothing> Shoes = new ArrayList<>();
    ArrayList<Clothing> Dresses = new ArrayList<>();
    String[] sizes = new String[3];
    String[] quantities = new String[3];
    PImage baggyJeans, flareLeggings, jorts, cargoPants, cargoShorts, flareJeans, hoodie, zipUp, tShirt, longSleeve, blouse, cropTop, bowlingShoes, runningShoes, highHeels, boots, sneakers, slides, bodycon, midi, maxi, mini, floral, fancy;

    Boolean singlePage, checkoutPage, mouseReleased;

    public void settings() {
        size(700, 600);
    }

    public void setup() {
        i = 0;
        tabIndex = 0;
        singlePage = false;
        checkoutPage = false;
        tabs.add("Pants");
        tabs.add("Tops");
        tabs.add("Dresses");
        tabs.add("Shoes");
        tabs.add("Accs");
        sizes = new String[]{"S", "M", "L"};
        baggyJeans = loadImage("baggyJeans.png");
        flareLeggings = loadImage("flareLeggings.png");
        jorts = loadImage("jorts.png");
        cargoPants = loadImage("cargoPants.png");
        flareJeans = loadImage("flareJeans.png");
        cargoShorts = loadImage("cargoShorts.png");
        hoodie = loadImage("hoodie.png");
        zipUp = loadImage("zipUp.png");
        tShirt = loadImage("shortSleeve.png");
        longSleeve = loadImage("longSleeve.png");
        blouse = loadImage("blouse.png");
        cropTop = loadImage("cropTop.png");
        bowlingShoes = loadImage("bowling.png");
        runningShoes = loadImage("running.png");
        sneakers = loadImage("sneaker.png");
        slides = loadImage("slides.png");
        boots = loadImage("boots.png");
        highHeels = loadImage("highHeels.png");
        bodycon = loadImage("bodyCon.png");
        midi = loadImage("midi.png");
        mini = loadImage("mini.png");
        maxi = loadImage("maxi.png");
        floral = loadImage("floral.png");
        fancy = loadImage("fancy.png");
        Pants.add(new Clothing("Baggy Jeans", 205.99, "M", "Grey", baggyJeans));
        Pants.add(new Clothing("Flare Leggings", 105.99, "M", "Black", flareLeggings));
        Pants.add(new Clothing("Jorts", 125.99, "M", "Blue", jorts));
        Pants.add(new Clothing("Cargo Pants", 325.99, "M", "Grey", cargoPants));
        Pants.add(new Clothing("Flare Jeans", 125.99, "M", "Blue", flareJeans));
        Pants.add(new Clothing("Cargo Shorts", 125.99, "M", "Brown", cargoShorts));
        Tops.add(new Clothing("Hoodie", 400, "M", "Grey", hoodie));
        Tops.add(new Clothing("Zip Up", 350.99, "M", "Black", zipUp));
        Tops.add(new Clothing("Tshirt", 149.99, "M", "Grey", tShirt));
        Tops.add(new Clothing("Long Sleeve", 215, "M", "Brown", longSleeve));
        Tops.add(new Clothing("Blouse", 450, "M", "Cream", blouse));
        Tops.add(new Clothing("Crop Top", 201.78, "M", "Beige", cropTop));
        Shoes.add(new Clothing("Bowling Shoes", 1000, "M", "Black", bowlingShoes));
        Shoes.add(new Clothing("Running Shoes", 100.92, "M", "White", runningShoes));
        Shoes.add(new Clothing("High Heels", 862.28, "M", "Blue", highHeels));
        Shoes.add(new Clothing("Boots", 452, "M", "Black", boots));
        Shoes.add(new Clothing("Slides", 182, "M", "Blue", slides));
        Shoes.add(new Clothing("Sneakers", 1000, "M", "Black", sneakers));
        Dresses.add(new Clothing("Bodycon", 136, "M", "Glittery", bodycon));
        Dresses.add(new Clothing("Maxi", 392, "M", "Multicolored", maxi));
        Dresses.add(new Clothing("Mini", 129, "M", "Emerald", mini));
        Dresses.add(new Clothing("Midi", 265, "M", "Pink", midi));
        Dresses.add(new Clothing("Floral", 275, "M", "MultiColored", floral));
        Dresses.add(new Clothing("Fancy", 3821, "M", "Blue", fancy));
    }

    public void draw() {
        runClickableAction();
        if (!checkoutPage) {
            ClothesToDisplay = getClothesToDisplay();
            drawMultiPage();
            drawCartButton();
            if (singlePage) {
                currClothing = getClothingToDisplay();
                drawSinglePage();
                drawExitButton();
                drawCartButton();
            }
        }else{
        drawCheckOutPage();
        drawExitButton();
        }
    }

    public void runClickableAction() {
        for (int i = 0; i < buttons.size(); i++) {
            Button b = buttons.get(i);
            if (b.mouseInside(this)) {
                b.invertColor();
                if (mouseReleased) {
                    if (b instanceof TabButton && !singlePage) {
                        tabIndex = ((TabButton) b).i;
                    }
                    if (b instanceof ClothingButton && !singlePage) {
                        clothingIndex = ((ClothingButton) b).i;
                        singlePage = true;
                    }
                    if (b instanceof ExitButton) {
                        singlePage = false;
                        checkoutPage = false;
                    }
                    if (b instanceof SizeButton) {
                        currClothing.size = sizes[((SizeButton) b).i];
                    }
                    if (b instanceof QuantityButton) {
                        if(((QuantityButton) b).i == 0 && currClothing.quantity != 1){
                            currClothing.quantity --;
                            break;
                        }
                        if(((QuantityButton) b).i == 2){
                            currClothing.quantity ++;
                            break;
                        }
                    }
                    if(b instanceof CartButton) {
                        checkoutPage = true;
                        singlePage = false;
                    }
                    if(b instanceof AddToCartButton){
                        ClothesInCart.add(currClothing);
                    }
                }
            }
        }
        mouseReleased = false;
    }

    public void centerText(String s, int x1, int x2, int y){
        float x = x1 + (x2 - x1)/2 - (textWidth(s)/2);
        text(s, x, y);
    }

    public void drawExitButton(){
        ExitButton e = new ExitButton(20, 20, 30, 30);
        buttons.add(e);
        textSize(30);
        e.draw(this, "X");
    }

    public void drawCartButton(){
        CartButton c = new CartButton(600, 13, 70, 33);
        buttons.add(c);
        textSize(15);
        c.draw(this, "Cart");
    }

    //drawing multi view pages
    public void drawMultiPage() {
        clear();
        background(255);
        fill(0);
        rect(50, 13, 70, 33);
        fill(255);
        centerText("LOGO", 50, 120, 33);

        //draw tabs button
        drawTabs();

        //draw clothing displays
        drawClothing(ClothesToDisplay);
    }

    public void drawTabs() {
        textSize(15);
        int x = 130;
        int y = 13;
        int w = 70;
        int h = 33;
        for (int i = 0; i < tabs.size(); i++) {
            String s = tabs.get(i);
            TabButton t = new TabButton(x, y, w, h, i);
            buttons.add(t);
            t.draw(this, s);
            x += 80;
        }
    }

    public void drawClothing(ArrayList<Clothing> clothes) {
        int x = 40;
        int y = 70;
        int s = 210;

        for (int i = 0; i < clothes.size(); i++) {
            Clothing c = clothes.get(i);
            if (x + s + 10 > width) {
                x = 40;
                y += s + 30;
            }
            ClothingButton d = new ClothingButton(x, y, s, s, i);
            buttons.add(d);
            d.draw(this, c);
            fill(0);
            textSize(15);
            text(c.name, x + 10, y + s + 10);
            String price = Double.toString(c.price);
            text(price, x + 150, y + s + 10);
            x += s + 10;
        }
    }

    public ArrayList<Clothing> getClothesToDisplay() {

        for (int i = 0; i < tabs.size(); i++) {
            String currentTab = tabs.get(tabIndex);
            if (currentTab.equals("Pants")) {
                return Pants;
            }
            if (currentTab.equals("Tops")) {
                return Tops;
            }
            if (currentTab.equals("Shoes")) {
                return Shoes;
            }
            if (currentTab.equals("Dresses")) {
                return Dresses;
            }
        }
        return Pants;
    }

    //drawing single view pages
    public void drawSinglePage(){
        int x = 20;
        int y = 50;
        int s = 400;
        clear();
        background(255);
        currClothing.draw(this, s, x, y);
        String price = currClothing.price + "";
        fill(0);
        textSize(30);
        centerText(currClothing.name, x + s, width, 90);
        text(price, 475, 1350);
        drawQuantityButtons();
        drawSizeButtons();
        drawAddToCartButton();
    }

    public void drawAddToCartButton(){
        AddToCartButton c = new AddToCartButton(450, 390, 230, 40);
        buttons.add(c);
        textSize(30);
        c.draw(this, "Add to Cart");
    }

    public Clothing getClothingToDisplay(){
        Clothing c = null;
        for (int i = 0; i < ClothesToDisplay.size(); i++) {
            c = ClothesToDisplay.get(clothingIndex);
        }
        return c;
    }

    public void drawSizeButtons(){
        int x = 450;
        int y = 270;
        int w = 70;
        int h = 40;
        for (int i = 0; i < sizes.length; i++) {
            String s = sizes[i];
            SizeButton b = new SizeButton(x, y, w, h, i);
            buttons.add(b);
            b.draw(this, s);
            x += 80;
        }
    }

    public void drawQuantityButtons(){
        quantities = new String[]{"-", String.valueOf(currClothing.quantity), "+"};
        int x = 450;
        int y = 330;
        int w = 70;
        int h = 40;
        for (int i = 0; i < quantities.length; i++) {
            String q = quantities[i];
            QuantityButton b = new QuantityButton(x, y, w, h, i);
            buttons.add(b);
            b.draw(this, q);
            x += 80;
        }
    }
    //drawing check out page
    public void drawCheckOutPage(){
        int x = 100;
        int y = 125;
        int s = 150;
        double totalPrice = 0;
        clear();
        background(255);
        fill(0);
        textSize(50);
        centerText("Cart", 0, width, 50);
        for (int i = 0; i < ClothesInCart.size(); i++) {
            Clothing c = ClothesInCart.get(i);

            rect(x, y, s, s);
            c.draw(this, s, x, y);
            textSize(14);
            text(c.name + " in the color " + c.color, x + s + 30, y + 20);

            rect(550, y, 55, 30);
            text("delete", 560, y+20);
            text(c.price +" dollars", x + s +30,y+50);
            text(c.quantity +" pieces", x + s + 80, y+50 );
            text(c.size, x + s + 30, y + 40);
            y = y + x + 80;
            totalPrice += c.price * c.quantity;
        }

    }

    public void mouseReleased(){
        mouseReleased = true;
    }

    public static void main (String[]args){
            PApplet.main("Main");
        }
}


