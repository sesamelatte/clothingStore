import processing.core.PApplet;
import processing.core.PImage;

import java.util.ArrayList;

public class Clothing {
    protected String name;
    public double price;
    protected String size;
    protected String[] colors;
    protected String color;
    protected int quantity;
    public PImage image;
    public Clothing(String n, double p, String s, String c , PImage picture){
        name = n;
        price = p;
        size = s;
        color = c;
        quantity = 1;
        image = picture;

    }
    public void draw(PApplet p, int s, int x, int y){
        PImage resizedImage = image.copy();  // Create a copy to avoid modifying the original image
        resizedImage.resize(s, s);
        p.image(resizedImage, x, y);
    }
    public double getPrice(){
        return price;
    }
}
